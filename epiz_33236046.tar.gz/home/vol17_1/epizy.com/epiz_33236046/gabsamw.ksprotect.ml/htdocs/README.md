# Portfolio Template
In case you are a developer who needs a portfolio, but you don't know much about front end, then don't worry; I got you covered with this template.
Simply install the app and customize the About Me, Skills and Project sections according to your details. 

**DEMO WEBSITE**: https://dev--portfolio-template.ctk-warrior.autocode.gg/

## 🤯 SHOWCASE
<img src="./readme/gallery/image1.png" alt="banner">

## 🔗 LINKS
- 💪 App Author: **CTK WARRIOR#7923**
- 🎥 Youtube: [DBD AND MORE](https://www.youtube.com/channel/UClAFgotVhZ1DGvN57EMY7fA)
- 💬 Discord: [Ctk's Server](https://withwin.in/dbd)
- 🛠 Tools Used: [Bootstrap v5](https://getbootstrap.com/), [Fontawesome](https://fontawesome.com/), [Google Fonts](https://fonts.google.com/), [Tippy](https://atomiks.github.io/tippyjs/)
